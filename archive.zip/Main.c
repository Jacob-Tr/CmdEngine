#include <stdio.h>
#include "TypeCast.h"
/*#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <float.h>
#define __CHAR_PTR_SIZE__ 4
#include "includes/Utils.h"
#define DEBUG
//#include "includes/Calculate.h"
//#include "includes/GameEngine.h"

linkedlist list;

int main(void)
{
	int a = 5;
	void* b = &a;
    T_PTR_CAST(a, Int, c);
	//fprintf(stdout, "%zu", sizeof(c));
	//INIT_SCREEN;
	
	//prtScr();
}*/








/*#include <stdio.h>

enum dynamic_type {
    Int,
    Float,
};

struct dynamic {
    enum dynamic_type type;
    union {
        int i;
        float f;
    };
};

void get_value(struct dynamic* ptr, enum dynamic_type type, void** output) {
    if (ptr->type == Int) {
        *(int**)output = &ptr->i;
    }
    if (ptr->type == Float) {
        *(float**)output = &ptr->f;
    }
}

#define GENERIC(x) (void**)&x

int main() {
    struct dynamic test = { .type = Int, .i = 5 };
    int* test_value = NULL;
    get_value(&test, Int, GENERIC(test_value));
    if (test_value) {
        printf("%i", *test_value);
    }
}*/


#include <stdio.h>

enum dynamic_type 
{
    Int,
    Float,
};

#define TYPE_MAP(x) __##x

enum dynamic_type_map 
{
    TYPE_MAP(int) = Int,
    TYPE_MAP(float) = Float
};

struct dynamic
{
    enum dynamic_type type;
    union 
    {
        int i;
        float f;
    };
};

void get_value(struct dynamic* ptr, int type, void* output) 
{
    if(ptr->type == type) 
    {
        if (ptr->type == Int) *((int*) output) = ptr->i;
        if (ptr->type == Float) *((float*) output) = ptr->f;
    }
}

#define GENERIC(x) (void*)&x

#define TRY_TYPE(ptr, type, output) type* output = NULL; get_value(ptr, TYPE_MAP(type), GENERIC(output));

/*#define FUNCT(Type, type) type* castFunc##Type(struct dynamic* ptr)

#define CAST_FUNC(Type, type) FUNCT(Type, type) {TRY_TYPE(ptr, type, output); return output;}

#define T_PTR_CAST(ptr, Type) castFunc##Type(ptr)

CAST_FUNC(Int, int)*/

int main(void) 
{
    struct dynamic test = {.type = Int, .i = 25635};

    struct dynamic* pt = &test;
    #define _CAST_PTR_ &test
    #define _CAST_OUT_ output
    
    #define _CAST_INT_
    #include "TypeCast.h"

    //TRY_TYPE(&test, int, test_value)
    
    printf("%i", output);
    
    /*if(test_value) printf("%i\n", *test_value);
    
    if(test_float_value) printf("%f\n", *test_float_value);*/
}