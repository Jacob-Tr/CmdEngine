#define _CAST_INT_
int