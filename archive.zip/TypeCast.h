#ifndef TYPE_CAST_H
#define TYPE_CAST_H

#define _CAST_CLEANED_
#define _CAST_OUT_ output

#ifdef _cplusplus
extern "C"
{
#endif

static inline void castCleanUp()
{
	#ifdef _INT_
	    #undef _INT_
	#endif
	#undef _CAST_PTR_
	#define _CAST_CLEANED_
}

static inline void dynCast()
{
	
}

#ifdef _cplusplus
}
#endif

#else
    #ifndef _CAST_PTR_
        #error "Unspecified "_CAST_PTR_" macro in dynamic cast."
    #endif
    
    #ifndef _CAST_CLEANED_
        #error "Failed to clean casting macros from last dynamic cast. (Previous cast failed)"
    #endif
    
    #undef _CAST_CLEANED_
    
    #define T_INC "int.h"
    #include T_INC
#endif

#define T_PTR_CAST(ptr, T, output) 


#ifdef _CAST_INT_
TRY_TYPE(_CAST_PTR_, int, _CAST_OUT_);
castCleanUp();
#endif